<template>
    <view class="body">
        <view class="top">
            <button size="mini" class="publish-btn" @tap="toPublish">
                {{ info ? '修改' : '发布' }}
            </button>
        </view>

        <view class="container">
            <view class="type">
                <view :class="'type-item ' + (type === '0' ? 'type-select' : '')" @tap="selectType" data-id="0">寻主</view>
                <view :class="'type-item ' + (type === '1' ? 'type-select' : '')" @tap="selectType" data-id="1">寻物</view>
            </view>
            <view v-if="type_check" class="error-tips">请选择寻物或寻主</view>
            <view class="classify">
                <text class="label">物品类别:</text>
                <picker class="picker" mode="multiSelector" @change="bindMultiPickerChange" @columnchange="bindMultiPickerColumnChange" :value="multiIndex" :range="multiArray">
                    <view class="picker-item">
                        <view class="select" v-if="select">
                            <text>{{ multiArray[0][multiIndex[0]] }} / {{ multiArray[1][multiIndex[1]] }}</text>
                            <image @tap.stop.prevent="closeSelect" class="select-icon" src="/static/images/close1.png"></image>
                        </view>
                        <view class="empty" v-else>
                            <text>请选择</text>
                            <image class="select-icon" src="/static/images/select.png"></image>
                        </view>
                    </view>
                </picker>
            </view>
            <view class="input-list">
                <view class="input-item">
                    <input :value="name" placeholder="请输入物品名称" @input="getName" type="text" />
                    <view v-if="name_check" class="error-tips">请输入少于20字的物品名称</view>
                </view>
                <view class="input-item">
                    <input :value="date" placeholder="请输入丢失/拾取时间" @input="getDate" type="text" />
                    <view v-if="date_check" class="error-tips">请输入少于20字的时间点</view>
                </view>
                <view class="input-item">
                    <input :value="region" placeholder="请输入丢失/拾取地点" @input="getRegion" type="text" />
                    <view v-if="region_check" class="error-tips">请输入少于20字的地点</view>
                </view>
                <view class="input-item">
                    <input :value="phone" placeholder="如何联系你？如: qq123456789等" @input="getPhone" type="text" />
                    <view v-if="phone_check" class="error-tips">请输入少于30字的联系信息</view>
                </view>
            </view>
            <view class="desc">
                <textarea :value="desc" placeholder="请输入物品描述" id="" cols="25" rows="10" @input="getDesc"></textarea>
                <image v-if="desc.length > 0" class="close-icon" src="/static/images/close1.png" @tap="deleteDesc"></image>
            </view>
            <view class="upload">
                <view class="upload-top">
                    <text>最多选择6张图片</text>
                    <text>{{ imgList.length }}/6</text>
                </view>
                <view class="upload-list">
                    <view class="img-list" v-for="(item, index) in imgList" :key="index">
                        <image class="common" :src="item"></image>

                        <image @tap="deleteImg" :data-index="index" class="delete" src="/static/images/close1.png"></image>
                    </view>
                    <image v-if="imgList.length < 6" class="default" src="/static/images/upload.png" @tap="uploadImg"></image>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
// pages/publish/publish.js
import { ajax } from '../../utils/index';
export default {
    data() {
        return {
            multiArray: [
                ['卡片、证件类', '数码产品', '美妆护肤类', '衣服物品类', '文娱', '其他'],
                ['身份证', '学生证', '水卡', '其他']
            ],
            pickerList: [
                ['身份证', '学生证', '水卡', '其他'],
                ['手机', '耳机', '数码相机', '智能手表', '其他'],
                ['口红', '粉底液', '水乳', '其他'],
                ['衣物', '水杯', '钥匙', '其他'],
                ['羽毛球类', '篮球', '图书', '其他'],
                ['其他']
            ],
            multiIndex: [0, 0],
            select: false,
            name: '',
            date: '',
            region: '',
            phone: '',
            desc: '',
            imgList: [],
            type: '',
            type_check: false,
            name_check: false,
            date_check: false,
            region_check: false,
            phone_check: false,
            id: '',
            info: null
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    async onLoad(options) {
        const { info } = options;
        const { multiArray, pickerList } = this;
        if (info) {
            const _info = JSON.parse(info);
            // const params = {
            //     _id: id
            // };
            // const { data } = await ajax('/getDetail', 'POST', params);
            const { type, classify1, classify2, name, date, region, phone, desc, imgList } = _info;
            const index1 = multiArray[0].findIndex((item) => item === classify1);
            const index2 = pickerList[index1].findIndex((item) => item === classify2);
            this.setData({
                type: String(type),
                multiArray: [multiArray[0], pickerList[index1]],
                multiIndex: [index1, index2],
                select: true,
                name,
                date,
                region,
                phone,
                desc,
                imgList,
                // id
                info: _info
            });
        }
        const userInfo = uni.getStorageSync('userInfo');
        if (userInfo && userInfo.phone) {
            this.setData({
                phone: userInfo.phone
            });
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        async toPublish() {
            /**
             *  type: 失物招领的类型  0 => 寻物  1 => 寻主
             *  classify1: 一级分类
             *  classify2: 二级分类
             *  name: 物品名称
             *  date: 丢失/拾取时间
             *  region: 丢失/拾取地点
             *  phone: 联系方式
             *  desc: 物品描述
             *  imgList: 上传的图片
             *  time: 发布时间
             */

            // multiArray[0][multiIndex[0]]
            const { type, multiArray, multiIndex, name, date, region, phone, desc, imgList, select, id, info } = this;
            if (!type) {
                this.setData({
                    type_check: true
                });
            }
            if (!name) {
                this.setData({
                    name_check: true
                });
            }
            if (!date) {
                this.setData({
                    date_check: true
                });
            }
            if (!region) {
                this.setData({
                    region_check: true
                });
            }
            if (!phone) {
                this.setData({
                    phone_check: true
                });
            }
            if (!type || !select || !name || !date || !region || !phone) {
                uni.showToast({
                    title: '未填写必填项',
                    icon: 'none'
                });
                return;
            }
            if (info) {
                // 修改
                const params = {
                    openid: uni.getStorageSync('openid'),
                    type: Number(type),
                    classify1: multiArray[0][multiIndex[0]],
                    classify2: multiArray[1][multiIndex[1]],
                    name,
                    date,
                    region,
                    phone,
                    desc,
                    imgList,
                    time: new Date().getTime(),
                    id: info._id
                };
                const { data } = await ajax('/updateLose', 'POST', params);
                if (data === 'success') {
                    uni.switchTab({
                        url: '../index/index',
                        success: () => {
                            uni.showToast({
                                icon: 'none',
                                title: '修改成功!'
                            });
                        }
                    });
                } else {
                    uni.showToast({
                        title: '修改失败!',
                        icon: 'none'
                    });
                }
            } else {
                // 发布
                const params = {
                    openid: uni.getStorageSync('openid'),
                    type: Number(type),
                    classify1: multiArray[0][multiIndex[0]],
                    classify2: multiArray[1][multiIndex[1]],
                    name,
                    date,
                    region,
                    phone,
                    desc,
                    imgList,
                    time: new Date().getTime()
                };
                const result = await ajax('/publish', 'POST', params);
                const { data } = result;
                if (data === 'success') {
                    uni.switchTab({
                        url: '../index/index',
                        success: () => {
                            uni.showToast({
                                icon: 'none',
                                title: '发布成功!'
                            });
                        }
                    });
                } else {
                    uni.showToast({
                        title: '发布失败!',
                        icon: 'none'
                    });
                }
            }
        },

        backPage() {
            // wx.navigateBack();
            uni.switchTab({
                url: '../index/index'
            });
        },

        selectType(e) {
            const { id } = e.currentTarget.dataset;
            this.setData({
                type: id,
                type_check: false
            });
        },

        deleteImg(e) {
            let { index } = e.currentTarget.dataset;
            let { imgList } = this;
            imgList.splice(index, 1);
            this.setData({
                imgList
            });
        },

        deleteDesc() {
            this.setData({
                desc: ''
            });
        },

        // uploadImg() {
        //     let { imgList } = this;
        //     uni.chooseMedia({
        //         count: 6 - imgList.length,
        //         mediaType: ['img'],
        //         sourceType: ['album', 'camera'],
        //         success: (res) => {
        //             const { tempFiles } = res;
        //             tempFiles.forEach((item, index) => {
        //                 uni.uploadFile({
        //                     url: 'http://127.0.0.1:3001/uploadImg',
        //                     filePath: item.tempFilePath,
        //                     name: 'file',
        //                     success: (res) => {
        //                         const { data } = res;
        //                         let { path } = JSON.parse(data)[0];
        //                         let __path = path.split('\\');
        //                         let _path = `http://127.0.0.1:3001/${__path[0]}/${__path[1]}`;
        //                         console.log(_path);
        //                         imgList.unshift(_path);
        //                         this.setData({
        //                             imgList
        //                         });
        //                     }
        //                 });
        //             });
        //         }
        //     });
        // },
		
		uploadImg() {
		    let { imgList } = this;
		    uni.chooseImage({
		        count: 6 - imgList.length,
		        success: (res) => {
		            const { tempFiles } = res;
		            tempFiles.forEach((item, index) => {
		                uni.uploadFile({
		                    url: 'http://127.0.0.1:3001/uploadImg',
		                    filePath: item.path,
		                    name: 'file',
		                    success: (res) => {
		                        const { data } = res;
		                        let { path } = JSON.parse(data)[0];
		                        let __path = path.split('\\');
		                        let _path = `http://127.0.0.1:3001/${__path[0]}/${__path[1]}`;
		                        this.addImageToList(_path);
		                    }
		                });
		            });
		        }
		    });
		},
		// 添加图片到imgList中
		addImageToList(path) {
		    let { imgList } = this;
		    imgList.unshift(path);
		    this.setData({
		        imgList
		    });
		},


        getName(e) {
            console.log(e.detail.value);
            this.setData({
                name: e.detail.value,
                name_check: false
            });
        },

        getDate(e) {
            this.setData({
                date: e.detail.value,
                date_check: false
            });
        },

        getRegion(e) {
            this.setData({
                region: e.detail.value,
                region_check: false
            });
        },

        getPhone(e) {
            this.setData({
                phone: e.detail.value,
                phone_check: false
            });
        },

        getDesc(e) {
            // 如果不希望去掉多余空格, 就去掉.trim()
            this.setData({
                desc: e.detail.value.trim()
            });
        },

        closeSelect() {
            this.setData({
                select: false,
                multiIndex: [0, 0]
            });
        },

        bindMultiPickerChange(e) {
            this.setData({
                select: true
            });
        },

        bindMultiPickerColumnChange(e) {
            let { column, value } = e.detail;
            let data = this;
            let { multiArray, pickerList } = this;
            if (column === 0) {
                // 替换展示的数据源
                multiArray[1] = pickerList[value];
            }
            data.multiArray = multiArray;
            data.multiIndex[column] = value;
            this.setData(data);
        }
    }
};
</script>
<style>
.body {
    width: 100vw;
    min-height: 100vh;
    background-color: #fff;
}

.top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 30rpx 35rpx;
    width: 100%;
    box-sizing: border-box;
    border-bottom: 5rpx solid #f3f3f3;
    margin-left: 70%;
}

.top .publish-btn {
    margin: 0 !important;
    background-color: #00bfff;
    color: #fff;
    border-radius: 40rpx;
    width: 150rpx;
}

.container {
    /* 上右下左 */
    padding: 30rpx 35rpx 50rpx 35rpx;
}

.type {
    display: flex;
}

.type .type-item {
    background-color: #eee;
    padding: 10rpx 70rpx;
    border: 1rpx solid #aaa;
    margin-right: 30rpx;
    border-radius: 10rpx;
}

.type .type-select {
    background-color: #00bfff;
    color: #fff;
}

.classify {
    margin-top: 50rpx;
    display: flex;
    width: 100%;
    align-items: center;
}

.classify .label {
    margin-right: 20rpx;
    white-space: nowrap;
}

.classify .picker {
    width: 100%;
}

.picker .empty,
.select {
    border: 2rpx solid #aaa;
    width: 100%;
    padding: 10rpx 20rpx;
    box-sizing: border-box;
    border-radius: 15rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.picker .empty .select-icon {
    width: 50rpx;
    height: 50rpx;
}

.picker .select .select-icon {
    width: 40rpx;
    height: 40rpx;
}

.input-list {
    padding: 30rpx 15rpx;
    padding-top: 80rpx;
    border-bottom: 5rpx solid #f3f3f3;
}

.input-list .input-item {
    margin-bottom: 50rpx;
}

.desc {
    padding: 30rpx 15rpx;
    border-bottom: 5rpx solid #f3f3f3;
    position: relative;
}

.desc .close-icon {
    width: 40rpx;
    height: 40rpx;
    position: absolute;
    top: 30rpx;
    right: 0;
}

.upload {
    padding-top: 20rpx;
}

.upload .upload-top {
    display: flex;
    justify-content: space-between;
}

.upload .upload-list {
    display: flex;
    flex-wrap: wrap;
    margin-top: 20rpx;
}

.upload .upload-list .default {
    width: 33%;
    height: 250rpx;
}

.img-list {
    width: 33%;
    height: 250rpx;
    position: relative;
}

.img-list .common {
    width: 100%;
    height: 100%;
}

.img-list .delete {
    width: 40rpx;
    height: 40rpx;
    position: absolute;
    top: 0rpx;
    right: 0rpx;
}

.error-tips {
    color: #f00;
    font-size: 26rpx;
}
</style>
