<template>
    <view>
        <view class="body">
            <SearchInput @tap.native="toSearch" />
            <swiper class="banner" :indicator-dots="true" :autoplay="true" interval="2000" duration="500">
                <block v-for="(item, index) in background" :key="index">
                    <swiper-item>
                        <image class="banner-image" :src="item"></image>
                    </swiper-item>
                </block>
            </swiper>

            <Tab @gettab="getTab" :tabList="tabList" />

            <view class="lose">
                <ViewCard :data="item" @tap.native="toDetail($event, { info: item })" :data-info="item" v-for="(item, index) in list" :key="index"></ViewCard>
            </view>
        </view>
       <!-- <view v-else>请您登录</view> -->
    </view>
</template>

<script>
// import SearchInput from '../../components/SearchInput/SearchInput';
// import Tab from '../../components/Tab/Tab';
// import ViewCard from '../../components/ViewCard/ViewCard';
import { formatTime, ajax } from '../../utils/index';
export default {
    components: {
        SearchInput,
        Tab,
        ViewCard
    },
    data() {
        return {
            background: ['/static/images/OIP-C (1).jpg', '/static/images/OIP-C (2).jpg', '/static/images/OIP-C.jpg'],
            tabList: ['寻主', '寻物'],
            select: 0,
            list: [],
            login: false
        };
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.onLoadClone3389(options);
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.onLoadClone3389({});
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                select: 0
            });
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {},
    methods: {
        /**
         * 生命周期函数--监听页面加载
         */
        onLoadClone3389: async function (options) {
            const { select } = this;
            const params = {
                type: select
            };
            this.setData({
                login: uni.getStorageSync('login')
            });
            if (!uni.getStorageSync('login_account')) {
                uni.redirectTo({
                    url: '../login/login'
                });
            } else {
                const result = await ajax('/getLose', 'GET', params);
                const { data } = result;
                this.setData({
                    list: data.map((item) => {
                        return {
                            ...item,
                            time: formatTime(item.time)
                        };
                    })
                });
                const openid = uni.getStorageSync('openid');
                if (!openid) {
                    const { code } = await uni.login();
                    const params1 = {
                        code
                    };
                    const result1 = await ajax('/login', 'GET', params1);
                    const { data } = result1;
                    if (data !== 'error') {
                        uni.setStorageSync('openid', data);
                    }
                }
            }
        },

        toSearch() {
            uni.navigateTo({
                url: '../search/search'
            });
        },

        toDetail(e, _dataset) {
            /* ---处理dataset begin--- */
            this.handleDataset(e, _dataset);
            /* ---处理dataset end--- */
            const {
                info: { _id, state }
            } = e.currentTarget.dataset;
            // if (state === 2) {
            //     wx.showToast({
            //       title: '该物品已认领, 如有疑问联系管理员',
            //       icon: 'none'
            //     })
            //     return;
            // }

            uni.navigateTo({
                url: `../infoDetail/infoDetail?_id=${_id}`
            });
        },

        getTab(e) {
            this.setData({
                select: e.detail
            });
            this.onLoadClone3389({});
        }
    }
};
</script>
<style>
.banner {
    height: 400rpx;
}

.banner-image {
    width: 100%;
    height: 400rpx;
}

.lose {
    display: flex;
    flex-direction: column;
}

.body {
    padding-bottom: 200rpx;
}
</style>
