<template>
    <view class="body">
        <view class="search">
            <image class="search-icon" src="/static/images/search.png"></image>
            <input :value="search_var" placeholder="搜索" @input="getSearch" type="text" />
            <image v-if="search_var.length > 0" class="close-icon" src="/static/images/close1.png" @tap="deleteSearch"></image>
        </view>
        <view class="empty-search" v-if="search.length === 0">
            <view class="search-log">
                <text>搜索历史</text>
                <image class="delete-icon" src="/static/images/delete.png" @tap="deleteLog"></image>
            </view>
            <view class="log-list">
                <view class="log-item" @tap="toSearchLog" :data-name="item" v-for="(item, index) in searchLog" :key="index">{{ item }}</view>
            </view>
        </view>
        <view class="result-search" v-else>
            <view class="search-item" @tap="toDetail" :data-info="item" v-for="(item, index) in searchRes" :key="index">
                <text>{{ item.name }}</text>

                <image class="search-item-right" src="/static/images/dayu.png"></image>
            </view>
        </view>
    </view>
</template>

<script>
// pages/search/search.js
import { ajax } from '../../utils/index';
let t = null;

// 1. 进入到页面时, 在onLoad里, 获取缓存中的searchLog, 进行赋值展示
// 2. 页面内, 通过wx:for动态渲染searchLog
// 3. 当搜索框延迟响应时, 将本次搜索内容添加到缓存中数据的头部, 并对页面内的数据进行赋值, 达到动态展示的效果

export default {
    data() {
        return {
            // 延迟响应
            search: '',
            // 及时响应
            search_var: '',
            // 搜索历史
            searchLog: [],
            // 搜索结果
            searchRes: []
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad(options) {
        const searchLog = uni.getStorageSync('searchLog');
        this.setData({
            searchLog
        });
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        toSearchLog(e) {
            const { name } = e.currentTarget.dataset;
            uni.navigateTo({
                url: `../searchResult/searchResult?name=${name}`
            });
        },

        toDetail(e) {
            const {
                info: { _id }
            } = e.currentTarget.dataset;
            uni.navigateTo({
                url: `../infoDetail/infoDetail?_id=${_id}`
            });
        },

        deleteLog() {
            // 删除视图内的数据
            this.setData({
                searchLog: []
            });
            // 删除缓存中的数据
            uni.removeStorageSync('searchLog');
        },

        deleteSearch() {
            this.setData({
                search: '',
                search_var: ''
            });
        },

        getSearch(e) {
            // 实现简单版本的防抖
            this.setData({
                search_var: e.detail.value
            });
            if (t) {
                clearTimeout(t);
            }
            t = setTimeout(async () => {
                this.setData({
                    search: e.detail.value
                });
                let searchLog = uni.getStorageSync('searchLog');
                if (searchLog) {
                    // 缓存有值的时候
                    searchLog.unshift(e.detail.value);
                } else {
                    // 没有缓存的时候
                    searchLog = [e.detail.value];
                }
                uni.setStorageSync('searchLog', searchLog);
                this.setData({
                    searchLog
                });
                const params = {
                    name: e.detail.value
                };
                const result = await ajax('/searchLose', 'GET', params);
                console.log(result);
                const { data } = result;
                this.setData({
                    searchRes: data
                });
            }, 1000);
            // 当你输入的内容，在数据库中能查到，就切换视图
        }
    }
};
</script>
<style>
.body {
    background-color: #fff;
    width: 100vw;
    min-height: 100vh;
    padding-top: 20rpx;
}

.search {
    display: flex;
    width: 90%;
    margin: 0 auto;
    background-color: #f3f3f3;
    border-radius: 40rpx;
    padding: 10rpx 20rpx;
    align-items: center;
    box-sizing: border-box;
    position: relative;
}

.search .search-icon {
    width: 40rpx;
    height: 40rpx;
    margin-right: 10rpx;
}

.search .close-icon {
    width: 40rpx;
    height: 40rpx;
    position: absolute;
    right: 20rpx;
}

.search-log {
    display: flex;
    padding: 30rpx 20rpx;
    justify-content: space-between;
    font-size: 26rpx;
    border-bottom: 3rpx solid #f3f3f3;
}

.search-log .delete-icon {
    width: 40rpx;
    height: 40rpx;
}

.log-list {
    display: flex;
    flex-wrap: wrap;
    padding: 15rpx 20rpx;
    font-size: 26rpx;
}

.log-list .log-item {
    background-color: #999;
    color: #fff;
    padding: 10rpx;
    margin-right: 15rpx;
    border-radius: 15rpx;
    margin-bottom: 5rpx;
}

.result-search {
    display: flex;
    flex-direction: column;
    margin-top: 30rpx;
}

.search-item {
    display: flex;
    justify-content: space-between;
    width: 100%;
    padding: 20rpx 30rpx;
    /* 盒模型 */
    box-sizing: border-box;
    border-bottom: 3rpx solid #f3f3f3;
    font-size: 26rpx;
}

.search-item-right {
    width: 30rpx;
    height: 30rpx;
}
</style>
