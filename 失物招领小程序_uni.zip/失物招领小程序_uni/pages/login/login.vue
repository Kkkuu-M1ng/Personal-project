<template>
    <view class="body">
        <image class="logo" src="/static/images/zjgsu.png" />
        <view class="container">
            <input class="input" placeholder="请输入账号" @input="getUsername" type="text" />
            <input class="input" placeholder="请输入密码" @input="getPassword" type="text" />
            <text class="to-register" @tap="toRegister">去注册</text>
            <button class="login-btn" type="primary" @tap="submit">登录</button>
        </view>
    </view>
</template>

<script>
// pages/login/login.js
import { ajax } from '../../utils/index';
export default {
    data() {
        return {
            username: '',
            password: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    async onLoad(options) {
        const openid = uni.getStorageSync('openid');
        if (uni.getStorageSync('login_account')) {
            uni.switchTab({
                url: '../index/index'
            });
        } else {
            if (!openid) {
                const { code } = await uni.login();
                const params1 = {
                    code
                };
                const result1 = await ajax('/login', 'GET', params1);
                const { data } = result1;
                if (data !== 'error') {
                    uni.setStorageSync('openid', data);
                }
            }
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        async submit() {
            const { username, password } = this;

            // 判断必填项是否未填
            if (!username || !password) {
                uni.showToast({
                    title: '存在未填项!',
                    icon: 'none'
                });
                return;
            }
            const params = {
                username,
                password
            };
            const result = await ajax('/toLogin', 'POST', params);
            const { data } = result;
            if (data === 'pwdError') {
                // 填写的密码不对
                uni.showToast({
                    title: '密码错误!',
                    icon: 'none'
                });
                return;
            } else if (data === 'error') {
                // 账号信息不存在
                uni.showToast({
                    title: '请检查您的账号是否正确!',
                    icon: 'none'
                });
                return;
            } else if (data === 'success') {
                // 登录成功
                uni.setStorageSync('login_account', true);
                uni.setStorageSync('account', params);
                uni.switchTab({
                    url: '../index/index',
                    success: () => {
                        uni.showToast({
                            title: '登录成功!',
                            icon: 'none'
                        });
                    }
                });
            }
        },

        getUsername(e) {
            this.setData({
                username: e.detail.value
            });
        },

        getPassword(e) {
            this.setData({
                password: e.detail.value
            });
        },

        toRegister() {
            uni.redirectTo({
                url: '../register/register'
            });
        }
    }
};
</script>
<style>
.body {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 100rpx;
}

.logo {
    width: 500rpx;
    height: 500rpx;
    /* border-radius: 50%; */
}

.container {
    margin-top: 50rpx;
    width: 70%;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.input {
    width: 100%;
    border-bottom: 2rpx solid rgb(212, 188, 188);
    margin-top: 60rpx;
}

.to-register {
    margin-right: auto;
    color: red;
    margin-top: 40rpx;
}

.login-btn {
    width: 90% !important;
    margin-top: 80rpx;
    border-radius: 40rpx;
}
</style>
