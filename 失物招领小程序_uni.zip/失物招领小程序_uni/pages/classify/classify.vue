<template>
    <view class="body">
        <SearchInput @tap.native="toSearch" />
        <view class="classify-container">
            <view class="classify-left">
                <view
                    :class="'classify-left-item ' + (select === index ? 'classify-select' : '')"
                    :data-index="index"
                    @tap="selectLeft"
                    v-for="(item, index) in asideBar"
                    :key="index"
                >
                    <text class="classify-left-text">{{ item }}</text>

                    <block v-if="select === index">
                        <view class="classify-line"></view>
                    </block>
                </view>
            </view>
            <view class="classify-right">
                <!-- wx:key 自己添加 -->
                <view class="classify-right-item" @tap="toClassify" :data-text="item.text" v-for="(item, index) in rightList[select]" :key="index">
                    <image class="classify-right-image" :src="item.url"></image>

                    <text class="classify-right-text">{{ item.text }}</text>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
// import SearchInput from '../../components/SearchInput/SearchInput';
// pages/classify/classify.js
export default {
    components: {
        SearchInput
    },
    data() {
        return {
            asideBar: ['卡片、证件类', '数码产品', '美妆护肤类', '衣服物品类', '文娱', '其他'],
            rightList: [
                [
                    {
                        url: '/static/images/id.png',
                        text: '身份证'
                    },
                    {
                        url: '/static/images/Sid.png',
                        text: '学生证'
                    },
                    {
                        url: '/static/images/Wid.png',
                        text: '水卡'
                    },
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ],
                [
                    {
                        url: '/static/images/phone.png',
                        text: '手机'
                    },
                    {
                        url: '/static/images/ear.png',
                        text: '耳机'
                    },
                    {
                        url: '/static/images/xiangji.png',
                        text: '数码相机'
                    },
                    {
                        url: '/static/images/watch.png',
                        text: '智能手表'
                    },
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ],
                [
                    {
                        url: '/static/images/red.png',
                        text: '口红'
                    },
                    {
                        url: '/static/images/fendi.png',
                        text: '粉底液'
                    },
                    {
                        url: '/static/images/shuiru.png',
                        text: '水乳'
                    },
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ],
                [
                    {
                        url: '/static/images/yi.png',
                        text: '衣物'
                    },
                    {
                        url: '/static/images/cup.png',
                        text: '水杯'
                    },
                    {
                        url: '/static/images/key.png',
                        text: '钥匙'
                    },
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ],
                [
                    {
                        url: '/static/images/badminton.png',
                        text: '羽毛球类'
                    },
                    {
                        url: '/static/images/book.png',
                        text: '图书'
                    },
                    {
                        url: '/static/images/ball.png',
                        text: '篮球'
                    },
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ],
                [
                    {
                        url: '/static/images/else.png',
                        text: '其他'
                    }
                ]
            ],
            select: 0
        };
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {},
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                select: 1
            });
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        toSearch() {
            uni.navigateTo({
                url: '../search/search'
            });
        },

        toClassify(e) {
            const { text } = e.currentTarget.dataset;
            uni.navigateTo({
                url: `../classifyList/classifyList?text=${text}`
            });
        },

        selectLeft(e) {
            const { index } = e.currentTarget.dataset;
            this.setData({
                select: index
            });
        }
    }
};
</script>
<style>
.search {
    background-color: #00bfff !important;
}

.classify-container {
    display: flex;
    background-color: white;
}

.classify-left {
    display: flex;
    flex-direction: column;
}

.classify-left-item {
    background-color: #f3f3f3;
    padding: 40rpx 20rpx;
    text-align: center;
    font-size: 26rpx;
    position: relative;
}

/* 让左边选中时 一定不会换行 卡片、证件类 */
.classify-left-text {
    white-space: nowrap;
}

.classify-line {
    position: absolute;
    left: 0;
    width: 0;
    height: 50%;
    border: 6rpx solid #00bfff;
    background-color: #00bfff;
    top: 50%;
    transform: translateY(-50%);
}

.classify-select {
    background-color: white;
}

.classify-right {
    display: flex;
    /* 让它可以自己换行 */
    flex-wrap: wrap;
    width: 100%;
    align-content: flex-start;
}

.classify-right-item {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 33.3%;
    padding: 20rpx 0;
}

.classify-right-item .classify-right-image {
    width: 100rpx;
    height: 100rpx;
}

.classify-right-item .classify-right-text {
    font-size: 26rpx;
    padding: 10rpx 0;
}
</style>
