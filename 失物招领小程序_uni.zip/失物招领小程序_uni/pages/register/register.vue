<template>
    <view class="body">
        <image class="logo" src="/static/images/zjgsu.png" />
        <view class="container">
            <input class="input" placeholder="请输入账号" @input="getUsername" type="text" />
            <input class="input" placeholder="请输入密码" @input="getPassword" type="text" />
            <input class="input" placeholder="请再次确认密码" @input="getConfirmPwd" type="text" />
            <text class="to-register" @tap="toLogin">去登录</text>
            <button class="login-btn" type="primary" @tap="submit">注册</button>
        </view>
    </view>
</template>

<script>
// pages/register/register.js
import { ajax } from '../../utils/index';
export default {
    data() {
        return {
            username: '',
            password: '',
            confirmPwd: ''
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    async onLoad(options) {
        const openid = uni.getStorageSync('openid');
        if (!openid) {
            const { code } = await uni.login();
            const params1 = {
                code
            };
            const result1 = await ajax('/login', 'GET', params1);
            const { data } = result1;
            if (data !== 'error') {
                uni.setStorageSync('openid', data);
            }
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        async submit() {
            const { username, password, confirmPwd } = this;

            // 判断是否存在未填项
            if (!username || !password || !confirmPwd) {
                uni.showToast({
                    title: '存在未填项!',
                    icon: 'none'
                });
                return;
            }

            // 判断两次输入的密码是否一致
            if (password !== confirmPwd) {
                uni.showToast({
                    title: '两次输入密码不一致!',
                    icon: 'none'
                });
                return;
            }
            const params = {
                openid: uni.getStorageSync('openid'),
                username,
                password,
                date: new Date().getTime()
            };
            const result = await ajax('/register', 'POST', params);
            const { data } = result;
            if (data === 'Registered') {
                // 这个账号已被注册
                uni.showToast({
                    title: '此账号已被注册!',
                    icon: 'none'
                });
                return;
            } else if (data === 'success') {
                // 注册成功
                uni.redirectTo({
                    url: '../login/login',
                    success: () => {
                        uni.showToast({
                            title: '注册成功!',
                            icon: 'none'
                        });
                    }
                });
            }
        },

        getUsername(e) {
            this.setData({
                username: e.detail.value
            });
        },

        getPassword(e) {
            this.setData({
                password: e.detail.value
            });
        },

        getConfirmPwd(e) {
            this.setData({
                confirmPwd: e.detail.value
            });
        },

        toLogin() {
            uni.redirectTo({
                url: '../login/login'
            });
        }
    }
};
</script>
<style>
.body {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 100rpx;
}

.logo {
    width: 500rpx;
    height: 500rpx;
}

.container {
    margin-top: 50rpx;
    width: 70%;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.input {
    width: 100%;
    border-bottom: 2rpx solid rgb(212, 188, 188);
    margin-top: 60rpx;
}

.to-register {
    margin-right: auto;
    color: #ff70b4;
    margin-top: 40rpx;
}

.login-btn {
    width: 90% !important;
    margin-top: 80rpx;
    border-radius: 40rpx;
}
</style>
