<template>
    <view class="body">
        <!-- <view class="unlogin-body" v-if="!login">
            <view class="unlogin">
                 <image class="unlogin-image" src="/static/images/me.png"></image> 
                 <button class="unlogin-btn" open-type="getUserInfo" @tap="toLogin">微信一键登录</button>
            </view>
        </view> -->
        <view class="login">
            <view class="info">
				<image class="zjgsu" src="../../static/images/A.png"></image>
                <!-- <image class="avatarUrl" :src="avatarUrl"></image>
                <text class="nickName">{{ nickName }}</text> -->
            </view>
            <view class="cell-body">
                <view class="cell-list">
                    <view class="cell" :data-page="item.page" @tap="toDetail" v-for="(item, index) in cellList" :key="index">
                        <view class="cell-left">
                            <image class="cell-left-image" :src="item.url"></image>
                            <text class="cell-left-text">{{ item.text }}</text>
                        </view>

                        <view class="cell-right">
                            <image class="cell-right-image" src="/static/images/dayu.png"></image>
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
// pages/me/me.js
export default {
    data() {
        return {
            login: false,
            avatarUrl: '',
            nickName: '',
			username: '',
			phone: '',
            cellList: [
                {
                    url: '/static/images/publish.png',
                    text: '发布信息',
                    page: '../publish/publish'
                },
                {
                    url: '/static/images/collection1.png',
                    text: '我的收藏',
                    page: '../myCollection/myCollection'
                },
                {
                    url: '/static/images/info.png',
                    text: '我的信息',
                    page: '../myInfo/myInfo'
                },
                {
                    url: '/static/images/quit.png',
                    text: '退出登录'
                }
            ],

            select: 0
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad(options) {
        const savedUsername = uni.getStorageSync('username');
        const avatarUrl = uni.getStorageSync('avatarUrl');
        if (avatarUrl) {
            this.avatarUrl = avatarUrl;
        }
        if (savedUsername) {
            this.username = savedUsername; // 将用户名设置到页面数据中
        }
        this.setData({
            login: savedUsername !== '' // 检查缓存中是否存在用户名，如果存在则将 login 设为 true
        });
    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        if (typeof this.getTabBar === 'function' && this.getTabBar()) {
            this.getTabBar().setData({
                select: 4
            });
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        toDetail(e) {
            const { page } = e.currentTarget.dataset;
            if (page) {
                uni.navigateTo({
                    url: page
                });
            } else {
                uni.showModal({
                    title: '提示',
                    content: '确定退出吗?',
                    success: (res) => {
                        const { confirm } = res;
                        if (confirm) {
                            uni.removeStorageSync('login_account');
							uni.removeStorageSync('account');
                            this.setData({
                                login: false
                            });
                            uni.redirectTo({
                                url: '../login/login'
                            });
                        }
                    }
                });
            }
        },

        toLogin() {
            const savedUsername = uni.getStorageSync('username');
			const savedname = uni.getStorageSync('name');
            const savedAvatarUrl = uni.getStorageSync('avatarUrl');
            if (savedUsername === username) {
                this.setData({
                    login: true,
                    name: savedname,
                    avatarUrl: savedAvatarUrl
                });
            } else {
                // 用户未登录或缓存中不存在用户名，需要获取用户信息
				uni.removeStorageSync('phone');
				uni.removeStorageSync('name');
				uni.removeStorageSync('avatarUrl');
                uni.getUserProfile({
                    desc: '获取用户信息',
                    success: (res) => {
                        console.log(res);
                        const {
                            userInfo: { avatarUrl, name }
                        } = res;
                        // 将用户信息保存到缓存中
                        uni.setStorageSync('avatarUrl', avatarUrl);
                        uni.setStorageSync('name', name);
                        uni.setStorageSync('login', true);
                        this.setData({
                            login: true,
                            avatarUrl,
                            name: name
                        });
                    }
                });
            }
        }
    }
};
</script>
<style>
.unlogin-body {
    background-color: #fff;
    height: 100vh;
    width: 100vw;
}
.unlogin {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding-top: 40%;
}

.unlogin .unlogin-image {
    width: 150rpx;
    height: 150rpx;
}

.unlogin .unlogin-btn {
    margin-top: 50rpx;
    width: 80%;
    background-color: #00bfff;
    color: #fff;
    height: 100rpx;
    line-height: 2.1;
}

.zjgsu {
	width: 100%;
}

.info {
    background-color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 100rpx 0;
}

/* .info .avatarUrl {
    width: 200rpx;
    height: 200rpx;
    border-radius: 50%;
}

.info .nickName {
    color: #fff;
    margin-top: 30rpx;
} */

.cell-body {
    position: relative;
}

.cell-list {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: absolute;
    width: 100%;
    top: -20rpx;
}

.cell {
    display: flex;
    justify-content: space-between;
    width: 85%;
    background-color: #fff;
    padding: 30rpx 20rpx;
    border-radius: 20rpx;
    align-items: center;
    margin-bottom: 20rpx;
}

.cell-left {
    display: flex;
    align-items: center;
}

.cell-left .cell-left-image {
    width: 50rpx;
    height: 50rpx;
}

.cell-left .cell-left-text {
    margin-left: 20rpx;
}

.cell-right .cell-right-image {
    width: 30rpx;
    height: 30rpx;
}
</style>
