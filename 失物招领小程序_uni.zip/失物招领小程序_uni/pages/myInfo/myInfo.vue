<template>
    <view class="body">
        <view class="info">
            <view class="info-item">
                <text>头像</text>
                <image class="avatarUrl" :src="avatarUrl" @tap="uploadImg"></image>
            </view>
            <view class="info-item">
                <text>昵称</text>
                <input class="edit-input" type="text" :value="name" @input="getUsername" />
            </view>
            <view class="info-item">
                <text>联系方式</text>
				<input class="edit-input" type="text" :value="phone" @input="getPhone" />
                <!-- <view class="phone-right">
                    <view class="edit" v-if="edit">
                        <input class="edit-input" type="text" :value="phone" @input="getPhone" />
                        <image v-if="phone.length > 0" class="close-icon" src="/static/images/close.png" @tap="deletePhone"></image>
                    </view>
                    <view class="phone" v-else>{{ phone_var }}</view>
                    <view class="edit-status">
                        <image v-if="!edit" @tap="toEdit" class="edit-icon" src="/static/images/edit.png"></image>
                        <text v-else @tap="toEdit">取消</text>
                    </view>
                </view> -->
            </view>
            <button v-if="edit" class="btn" @tap="saveChange">保存修改</button>
        </view>
    </view>
</template>

<script>
// pages/myInfo/myInfo.js
export default {
    data() {
        return {
			avatarUrl: '',
			name: '',           
			edit: false,
			imgList: [],
			phone: '',
        };
    }
    /**
     * 生命周期函数--监听页面加载
     */,
    onLoad(options) {
        // 从本地存储中获取联系方式
        const savedPhone = uni.getStorageSync('phone');
		const avatarUrl = uni.getStorageSync('avatarUrl');
		const savedUsername = uni.getStorageSync('name');
		if (avatarUrl) {
		        this.avatarUrl = avatarUrl;
		    }
		if (savedUsername) {
			this.name = savedUsername;
		}
        // 如果本地存储中存在联系方式，则设置到组件数据中
        if (savedPhone) {
            this.setData({
                phone: savedPhone,
                phone_var: savedPhone // 可能你有一个显示联系方式的变量，也需要设置
            });
        }
    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {},
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {},
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {},
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {},
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {},
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {},
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {},
    methods: {
        saveChange() {
           const newPhone = this.phone; 
			const newUsername = this.name;
            uni.setStorageSync('phone', newPhone);
			uni.setStorageSync('name', newUsername);
           
            uni.showToast({
                title: '已保存',
                icon: 'success'
            });
        },

        deletePhone() {
            this.setData({
                phone: ''
            });
        },
		
		uploadImg() {
		    uni.chooseImage({
		        count: 1, // 限制只能选择一张图片
		        success: (res) => {
		            const tempFilePaths = res.tempFilePaths;
		            uni.uploadFile({
		                url: 'http://127.0.0.1:3001/uploadImg',
		                filePath: tempFilePaths[0], // 只上传选择的第一张图片
		                name: 'file',
		                success: (res) => {
		                    const { data } = res;
		                    let { path } = JSON.parse(data)[0];
		                    let __path = path.split('\\');
		                    let _path = `http://127.0.0.1:3001/${__path[0]}/${__path[1]}`;
		                    // 将上传成功的头像地址更新到页面上
		                    this.avatarUrl = _path;
							uni.setStorageSync('avatarUrl', _path);
							
		                }
		            });
		        }
		    });
		},


        getPhone(e) {
            const { value } = e.detail;
            this.setData({
                phone: value,
				edit: 1
            });
        },
		
		getUsername(e) {
		    const { value } = e.detail;
		    this.setData({
		        name: value,
				edit: 1
		    });
		},

        toEdit() {
            this.setData({
                edit: !this.edit,
                phone: this._phone
            });
        }
    }
};
</script>
<style>
.body {
    width: 100vw;
    height: 100vh;
    background-color: #fff;
}

.info {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 40rpx;
}

.info .info-item {
    display: flex;
    justify-content: space-between;
    width: 90%;
    align-items: center;
    height: 170rpx;
    border-bottom: 4rpx solid #f3f3f3;
}

.info .info-item .avatarUrl {
    width: 120rpx;
    height: 120rpx;
    border-radius: 50%;
    border: 5rpx solid #00bfff;
}

.phone-right {
    display: flex;
    align-items: center;
}

.info-item .edit-input {
    border: 2rpx solid #d3d3d3;
    padding: 15rpx 5rpx;
    margin-right: 20rpx;
}

.phone-right .edit-status .edit-icon {
    width: 40rpx;
    height: 40rpx;
}

.phone-right .edit {
    position: relative;
}

.phone-right .edit .close-icon {
    position: absolute;
    width: 30rpx;
    height: 30rpx;
    right: 40rpx;
    top: 50%;
    transform: translateY(-50%);
    z-index: 10;
}

.btn {
    width: 80% !important;
    background-color: #00bfff;
    color: #fff;
    margin-top: 50rpx;
}

.phone-right .phone {
    margin-right: 160rpx;
}
</style>
