<template>
    <view class="body">
        <swiper class="banner" :indicator-dots="true" :autoplay="false" interval="2000" duration="500">
            <block v-for="(item, index) in info.imgList" :key="index">
                <swiper-item>
                    <image class="banner-image" :src="item"></image>
                </swiper-item>
            </block>
        </swiper>

        <view class="name">{{ info.name }}</view>

        <view class="container">
            <view class="date item">
                <text class="label">拾到时间</text>
                <text>{{ info.date }}</text>
            </view>
            <view class="region item">
                <text class="label">拾到地点</text>
                <text>{{ info.region }}</text>
            </view>
            <view class="desc item">{{ info.desc }}</view>
        </view>

        <view class="comment">
            <view class="title">匿名评论区</view>
            <view class="comment-list">
                <view class="comment-item" v-for="(item, index) in info.commentList" :key="index">
                    <view class="comment-item-left">
                        <image class="avatar" :src="item.avatarUrl"></image>
                        <view class="content">
                            <text>{{ item.nickName }}</text>
                            <text>{{ item.content }}</text>
                        </view>
                    </view>

                    <view class="comment-item-right">
                        {{ item.time }}
                    </view>
                </view>
            </view>
            <textarea class="comment-textarea" placeholder="请输入您的评论内容" name="" id="" cols="30" rows="10" :value="comment" @input="getComment"></textarea>
            <button class="comment-button" type="primary" @tap="submitComment">提交</button>
        </view>

        <view class="bottom">
            <view class="bottom-left" @tap="getPhone">
                <image class="icon-comment" src="/static/images/comment.png"></image>
                <text>点击联系我</text>
            </view>
            <button class="bottom-mid" :disabled="info.state !== 0" size="mini" @tap="toClaim">{{ info.state === 0 ? '认领' : info.state === 1 ? '认领中' : '已认领' }}</button>
            <view class="bottom-right" @tap="toCollection">
                <image class="icon-collection" :src="collectionIcon[0]"></image>
                <text>收藏</text>
            </view>
        </view>

        <view class="modal" v-if="showModal">
            <view class="label">描述:</view>
            <textarea class="textarea" name="" id="" cols="30" rows="10" placeholder="请输入您的描述" :value="desc" @input="getDesc"></textarea>
            <view class="label">相关证明:</view>
            <button class="upload-btn" v-if="img_url.length === 0" @tap="uploadImg">上传</button>
            <image class="img" v-else :src="img_url"></image>
            <view class="btn-list">
                <button size="mini" @tap="cancel">取消</button>
                <button size="mini" type="primary" @tap="submit">确定</button>
            </view>
        </view>
    </view>
</template>

<script>
// pages/infoDetail/infoDetail.js
import { ajax, formatTime } from '../../utils/index';
export default {
    data() {
        return {
            background: ['/static/images/banner1.jpeg', '/static/images/banner2.jpeg'],
            collectionIcon: ['/static/images/collection1.png', '/static/images/collection1_fill.png'],
            info: {
                imgList: [],
                name: '',
                date: '',
                region: '',
                desc: '',
                commentList: [],
                state: 0
            },
            from: '',
            comment: '',
            showModal: false,
            desc: '',
            img_url: ''
        };
    }, // /**
    //  * 生命周期函数--监听页面加载
    //  */
    // /**
    //  * 生命周期函数--监听页面初次渲染完成
    //  */
    // onReady() {
    // },
    // /**
    //  * 生命周期函数--监听页面显示
    //  */
    // onShow() {
    // },
    // /**
    //  * 生命周期函数--监听页面隐藏
    //  */
    // onHide() {
    // },
    // /**
    //  * 生命周期函数--监听页面卸载
    //  */
    // onUnload() {
    // },
    // /**
    //  * 页面相关事件处理函数--监听用户下拉动作
    //  */
    // onPullDownRefresh() {
    // },
    // /**
    //  * 页面上拉触底事件的处理函数
    //  */
    // onReachBottom() {
    // },
    // /**
    //  * 用户点击右上角分享
    //  */
    // onShareAppMessage() {
    // }
    async onLoad(options) {
        const { collectionIcon } = this;
        const { _id } = options;
        console.log(_id);
        const _params = {
            _id
        };
        const { data: info } = await ajax('/getDetail', 'POST', _params);
        console.log(info);
        info.commentList.forEach((item) => {
            item.time = formatTime(item.time);
        });
        this.setData({
            info
        });
        const params = {
            id: _id,
            openid: uni.getStorageSync('openid')
        };
        const result = await ajax('/checkCollection', 'POST', params);
        const { data } = result;
        if (data.length > 0) {
            let last = collectionIcon.pop();
            collectionIcon.unshift(last);
            this.setData({
                collectionIcon
            });
        }
    },
    methods: {
        // uploadImg() {
        //     uni.chooseMedia({
        //         count: 1,
        //         mediaType: ['image'],
        //         sourceType: ['album', 'camera'],
        //         success: (res) => {
        //             const { tempFiles } = res;
        //             uni.uploadFile({
        //                 url: 'http://localhost:3001/uploadImg',
        //                 filePath: tempFiles[0].tempFilePath,
        //                 name: 'file',
        //                 success: (res) => {
        //                     const { data } = res;
        //                     let { path } = JSON.parse(data)[0];
        //                     let _path = `http://localhost:3001/${path}`;
        //                     console.log(_path);
        //                     this.setData({
        //                         img_url: _path
        //                     });
        //                 },
        //                 fail: (err) => {
        //                     console.log(err);
        //                 }
        //             });
        //         }
        //     });
        // },
		uploadImg() {
		    uni.chooseImage({
		        count: 1, // 限制只能选择一张图片
		        success: (res) => {
		            const tempFilePaths = res.tempFilePaths;
		            uni.uploadFile({
		                url: 'http://localhost:3001/uploadImg',
		                filePath: tempFilePaths[0], // 只上传选择的第一张图片
		                name: 'file',
		                success: (res) => {
		                    const { data } = res;
		                    let { path } = JSON.parse(data)[0];
		                    let __path = path.split('\\');
		                    let _path = `http://127.0.0.1:3001/${__path[0]}/${__path[1]}`;
		                    this.img_url = _path;
		                    uni.setStorageSync('img_url', _path); // 保存到本地缓存
		                },
		                fail: (err) => {
		                    console.log(err);
		                }
		            });
		        }
		    });
		},


        getDesc(e) {
            this.setData({
                desc: e.detail.value
            });
        },

        async submit() {
            const {
                desc,
                img_url,
                info: { _id }
            } = this;
            if (!desc || !img_url) {
                uni.showToast({
                    title: '存在必填项未填!',
                    icon: 'none'
                });
                return;
            }
            const params = {
                desc,
                img_url,
                openid: uni.getStorageSync('openid'),
                _id
            };
            const { data } = await ajax('/toClaim', 'POST', params);
            if (data === 'success') {
                this.setData({
                    showModal: false
                });
                uni.switchTab({
                    url: '../index/index',
                    success: () => {
                        uni.showToast({
                            title: '提交成功!',
                            icon: 'none'
                        });
                    }
                });
            } else {
                uni.showToast({
                    title: '提交失败!',
                    icon: 'none'
                });
            }
        },

        cancel() {
            this.setData({
                showModal: false
            });
        },

        toClaim() {
            this.setData({
                showModal: true
            });
        },

        async submitComment() {
            const {
                comment,
                info: { _id }
            } = this;
            if (comment.trim().length === 0) {
                uni.showToast({
                    title: '您输入的评论内容为空!',
                    icon: 'none'
                });
                return;
            }
            const { avatarUrl, nickName } = uni.getStorageSync('userInfo');
            const params = {
                avatarUrl,
                nickName,
                content: comment,
                time: new Date().getTime(),
                _id
            };
            const {
                data: { status, data }
            } = await ajax('/addComment', 'POST', params);
            if (status === 'success') {
                uni.showToast({
                    title: '评论成功!',
                    icon: 'none'
                });
                data.commentList.forEach((item) => {
                    item.time = formatTime(item.time);
                });
                this.setData({
                    info: data,
                    comment: ''
                });
            } else {
                uni.showToast({
                    title: '评论失败!',
                    icon: 'none'
                });
            }
        },

        getComment(e) {
            this.setData({
                comment: e.detail.value
            });
        },

        async toCollection() {
            const { info, collectionIcon, from } = this;
            const { _id } = info;
            if (collectionIcon[0] === '/static/images/collection1.png') {
                // 想收藏
                const params = {
                    id: _id,
                    openid: uni.getStorageSync('openid')
                };
                const result = await ajax('/toCollection', 'POST', params);
                const { data } = result;
                if (data === 'success') {
                    uni.showToast({
                        title: '收藏成功!',
                        icon: 'none'
                    });
                    let last = collectionIcon.pop();
                    collectionIcon.unshift(last);
                    this.setData({
                        collectionIcon
                    });
                }
            } else {
                // 想取消收藏
                const params = {
                    id: _id,
                    openid: uni.getStorageSync('openid')
                };
                const result = await ajax('/cancelCollection', 'POST', params);
                const { data } = result;
                if (data === 'success') {
                    uni.showToast({
                        title: '取消成功',
                        icon: 'none'
                    });
                    let last = collectionIcon.pop();
                    collectionIcon.unshift(last);
                    this.setData({
                        collectionIcon
                    });
                }
            }
        },

        getPhone() {
            const {
                info: { phone }
            } = this;
            uni.showModal({
                title: '联系方式',
                content: phone,
                confirmText: '复制',
                success: (res) => {
                    if (res.confirm) {
                        uni.setClipboardData({
                            data: phone,
                            success: (res) => {
                                uni.showToast({
                                    icon: 'none',
                                    title: '内容已复制'
                                });
                            }
                        });
                    }
                }
            });
        }
    }
};
</script>
<style>
.banner {
    height: 55vh;
}

.banner-image {
    width: 100%;
    height: 55vh;
}

.name {
    background-color: #fff;
    margin-top: 20rpx;
    padding: 20rpx;
    font-weight: bold;
}

.container {
    background-color: #fff;
    margin-top: 20rpx;
}

.container .item {
    padding: 20rpx;
    display: flex;
    align-items: center;
}

.container .item .label {
    width: 70rpx;
    color: #999999;
    font-size: 26rpx;
    margin-right: 20rpx;
}

.bottom {
    display: flex;
    background-color: #fff;
    justify-content: space-between;
    margin-top: 20rpx;
    padding: 20rpx 40rpx;
    box-sizing: border-box;
    position: absolute;
    width: 100%;
    bottom: 20rpx;
}

 .bottom-mid {
	display: flex;
	align-items: center;
	justify-content: center;
}

.bottom .bottom-left {
    display: flex;
    align-items: center;
    background-color: #f3f3f3;
    border-radius: 30rpx;
    padding: 10rpx;
    width: 60%;
    color: #999999;
}

.bottom .bottom-left .icon-comment {
    width: 40rpx;
    height: 40rpx;
    margin-left: 20rpx;
    margin-right: 10rpx;
}

.bottom .bottom-right .icon-collection {
    width: 40rpx;
    height: 40rpx;
}

.bottom .bottom-right {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.body {
    position: relative;
    padding-bottom: 160rpx;
}

.comment {
    background-color: #fff;
    margin-top: 20rpx;
    padding: 20rpx;
    box-sizing: border-box;
}

.comment .title {
    font-size: 40rpx;
    font-weight: 600;
    text-align: center;
}

.comment-list {
    margin-top: 20rpx;
    display: flex;
    flex-direction: column;
}

.comment-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20rpx;
}

.comment-item-left {
    display: flex;
    align-items: center;
}

.comment-item-left .avatar {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
}

.comment-item-left .content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-left: 20rpx;
}

.comment .comment-textarea {
    border: 1px solid #000;
    width: 100%;
    padding: 20rpx;
    box-sizing: border-box;
    border-radius: 20rpx;
}

.comment .comment-button {
    margin-top: 20rpx;
}

.modal {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);

    background-color: #eee;
    display: flex;
    flex-direction: column;
    padding: 40rpx;
    box-sizing: border-box;
    width: 90%;
    border-radius: 40rpx;
    z-index: 10;
}

.modal .textarea {
    border: 1rpx solid #000;
    border-radius: 40rpx;
    padding: 20rpx;
    box-sizing: border-box;
    margin: 20rpx 0;
}

.modal .upload-btn {
    margin: 20rpx auto;
}

.modal .img {
    width: 100%;
    height: 300rpx;
    margin: 20rpx 0;
}

.modal .btn-list {
    display: flex;
    margin-top: 20rpx;
}
</style>
