<template>
    <view class="tabbar">
        <view
            :class="'tabbar-item ' + (select === index ? 'tabbar-select' : '')"
            :data-page="item.pagePath"
            :data-index="item.index"
            :data-type="item.type"
            @tap="selectPage"
            v-for="(item, index) in list"
            :key="index"
        >
            <block v-if="item.type === 0">
                <image class="tabbar-image" :src="select === index ? item.selectedIconPath : item.iconPath"></image>
                <text class="tabbar-text">{{ item.text }}</text>
            </block>

            <block v-else>
                <view class="publish">
                    <image class="tabbar-image" src="/static/images/add.png"></image>
                </view>
            </block>
        </view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            select: 0,
            list: [
                {
                    iconPath: '/static/images/index.png',
                    pagePath: '/pages/index/index',
                    selectedIconPath: '/static/images/index_fill.png',
                    text: '首页',
                    type: 0
                },
                {
                    iconPath: '/static/images/classify.png',
                    pagePath: '/pages/classify/classify',
                    selectedIconPath: '/static/images/classify_fill.png',
                    text: '分类',
                    type: 0
                },
                {
                    type: 1,
                    pagePath: '/pages/publish/publish'
                },
                {
                    iconPath: '/static/images/collection.png',
                    pagePath: '/pages/collection/collection',
                    selectedIconPath: '/static/images/collection_fill.png',
                    text: '收藏夹',
                    type: 0
                },
                {
                    iconPath: '/static/images/me.png',
                    pagePath: '/pages/me/me',
                    selectedIconPath: '/static/images/me_fill.png',
                    text: '我的',
                    type: 0
                }
            ]
        };
    },
    methods: {
        selectPage(e) {
            const { index, page, type } = e.currentTarget.dataset;
            if (index !== this.select && type === 0) {
                uni.switchTab({
                    url: page
                });
            } else {
                if (!uni.getStorageSync('login')) {
                    uni.showToast({
                        title: '请您先登录!',
                        icon: 'none'
                    });
                    return;
                } else {
                    uni.navigateTo({
                        url: page
                    });
                }
            }
        }
    },
    created: function () {}
};
</script>
<style>
.tabbar {
    width: 100%;
    display: flex;
    background-color: #fff;
    position: fixed;
    bottom: 0;
    padding-bottom: env(safe-area-inset-bottom);
    padding-top: 10rpx;
    z-index: 9999;
}

.tabbar-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.tabbar-item .tabbar-image {
    width: 50rpx;
    height: 50rpx;
}

.tabbar-item .tabbar-text {
    font-size: 26rpx;
    margin-top: 10rpx;
}

.tabbar-item .publish {
    width: 65rpx;
    height: 65rpx;

    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: auto;
}

.tabbar-select {
    color: #00bfff;
}
</style>
