<template>
    <view class="tab">
        <view :class="'tab-item ' + (select !== index ? 'tab-default' : '')" @tap="selectTab" :data-id="index" v-for="(item, index) in tabList" :key="index">
            <text>{{ item }}</text>

            <view v-if="select === index" class="tab-line"></view>
        </view>
    </view>
</template>

<script>
export default {
    data() {
        return {
            select: 0
        };
    },
    props: {
        tabList: Array
    },
    methods: {
        selectTab(e) {
            const { id } = e.currentTarget.dataset;
            this.setData({
                select: id
            });
            this.$emit('gettab', {
                detail: id
            });
        }
    },
    created: function () {}
};
</script>
<style>
.tab {
    display: flex;
    width: 100%;
    background-color: #fff;
}

.tab-item {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 30rpx 0;
    position: relative;
}

.tab-line {
    position: absolute;
    width: 65%;
    height: 0;
    border: 3rpx solid #00bfff;
    bottom: 0;
}

.tab-default {
    background-color: #f3f3f3;
}
</style>
