<template>
    <view class="lose-body">
        <view class="lose-item">
            <image class="lose-item-image" :src="data.imgList[0]"></image>
            <view class="lose-content">
                <text class="name">{{ data.name }}</text>
                <text class="region">{{ data.region }}</text>
                <text class="date">{{ data.date }}</text>
                <text class="desc">{{ data.desc }}</text>
                <text class="publish-time">{{ data.time }}</text>
            </view>
        </view>
        <view class="handle-btn" v-if="handle">
            <view>
                <button class="update-btn" size="mini" type="primary" :data-info="data" @tap.stop.prevent="toUpdate">修改</button>
                <button class="delete-btn" size="mini" type="warn" :data-id="data._id" @tap.stop.prevent="toDelete">删除</button>
            </view>
        </view>
        <view class="mask" v-if="data.state === 2">已认领</view>
    </view>
</template>

<script>
export default {
    data() {
        return {};
    },
    props: {
        data: Object,
        handle: Boolean
    },
    methods: {
        toDelete(e) {
            const { id } = e.currentTarget.dataset;
            this.$emit('getdelete', {
                detail: id
            });
        },
        toUpdate(e) {
            const { info } = e.currentTarget.dataset;
            this.$emit('getupdate', {
                detail: JSON.stringify(info)
            });
        }
    },
    created: function () {}
};
</script>
<style>
.lose-item {
    width: 100%;
    display: flex;
    padding: 20rpx;
    background-color: #fff;
    box-sizing: border-box;
}

.lose-item .lose-item-image {
    width: 250rpx;
    height: 250rpx;
    min-width: 250rpx;
    border-radius: 20rpx;
}

.lose-content {
    display: flex;
    flex-direction: column;
    margin-left: 10rpx;
    width: 100%;
}

.lose-content .name {
    font-weight: bold;
}

.lose-content .region {
    margin-top: 35rpx;
}

.lose-content .region,
.date,
.desc {
    font-size: 26rpx;
    margin-bottom: 5rpx;
}

.lose-content .desc {
    max-width: 400rpx;
    color: #666;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}

.lose-content .publish-time {
    margin-top: 30rpx;
    margin-left: auto;
    color: #666;
    font-size: 26rpx;
}

.lose-body {
    background-color: #fff;
    margin-bottom: 5rpx;
    position: relative;
}

.handle-btn {
    display: flex;
    justify-content: flex-end;
}

.update-btn,
.delete-btn {
    margin-right: 20rpx;
}

.mask {
    position: absolute;
    top: 0;
    left: 0%;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.4);
    color: #fff;
    font-size: 50rpx;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>
