1. 下载nodejs框架express
npm install express --save
2. 切换npm镜像源为淘宝镜像源
npm config set registry https://registry.npm.taobao.org
3. 下载nodemon解决nodejs代码更新的痛点
npm install nodemon -g
4. nodejs连接mongodb数据库
npm install mongoose --save
5. 下载multer来实现文件上传存储
npm install multer --save
6. 下载uuid来实现不重复的字符串
npm install uuid --save
7. 下载axios实现网络请求
npm install axios --save

前端想访问后端, 就要通过接口来访问