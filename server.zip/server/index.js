const express = require('express');
const app = express();
const { Lose, Collection, User, Admin } = require('./db');
const multer = require('multer');
const { v4 } = require('uuid');
const axios = require('axios');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(__dirname));

app.all("*", (req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", '*');
    res.setHeader("Access-Control-Allow-Headers", '*');

    next();
})

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "./file")
    },
    filename: (req, file, cb) => {
        let type = file.originalname.replace(/.+\./, ".");
        console.log(type);
        cb(null, `${v4()}${type}`)
    }
})

const upload = multer({ storage });

// 实现物品的发布功能
app.post("/publish", async (req, res) => {
    // 1. 获取前端传过来的数据, 
    // 2. 将数据存入Lose数据表里
    try {
        const { type, classify1, classify2, name, date, region, phone, desc, imgList, time, openid } = req.body;
        await Lose.create({
            type, classify1, classify2, name, date, region, phone, desc, imgList, time, openid
        });
        res.send("success");
    } catch (error) {
        console.log(error);
        res.send("error");
    }
})

// 上传图片
app.post("/uploadImg", upload.array("file", 6), (req, res) => {
    res.send(req.files);
})

// 获取首页的数据
app.get("/getLose", async (req, res) => {
    const { type } = req.query;
    const result = await Lose.find({
        type,
    }).sort({ time: -1 });
    res.send(result);
})

// 收藏物品
app.post("/toCollection", async (req, res) => {
    try {
        const { id, openid } = req.body;
        await Collection.create({ 
            id, openid
        })
        res.send("success");
    } catch (error) {
        console.log(error);
        res.send("error");
    }

})

// 实现登录操作
// app.get("/login", async (req, res) => {
//     const { code } = req.query;
//     try {

//         const { data: { openid } } = await axios.get(`https://api.weixin.qq.com/sns/jscode2session?appid=wxd3b1e19cf596211e&secret=329daa720d6d112dd48fb711da9e58eb&js_code=${code}&grant_type=authorization_code`);
//         console.log(openid);

//         res.send(openid);
//     } catch (error) {
//         console.log(error);
//         res.send("error");
//     }
// })

// 查询当前物品有没有被当前这个人收藏过
app.post("/checkCollection", async (req, res) => {
    const { id, openid } = req.body;
    const result = await Collection.find({
        id,
        openid
    });
    res.send(result);
})

// 取消收藏
app.post("/cancelCollection", async (req, res) => {
    try {
        const { id, openid } = req.body;
        await Collection.findOneAndRemove({
            id,
            openid
        });
        res.send("success");
    } catch (error) {
        console.log(error);
        res.send("error");
    }
})

// 获取收藏夹的数据
app.post("/getCollection", async (req, res) => {
    const { openid, type } = req.body;
    const result = await Collection.find({
        openid
    }).populate('id');
    const _result = result.filter(item => item.id ? item.id.type === type : false);
    res.send(_result);
})


// 获取我的发布的数据
app.get("/getMyPublish", async (req, res) => {
    const { openid, type } = req.query;
    const result = await Lose.find({
        openid,
        type
    });
    res.send(result);
})

// 通过二级分类查数据
app.post("/getClassifyTwo", async (req, res) => {
    const { type, classify2 } = req.body;
    const result = await Lose.find({
        type,
        classify2
    });
    res.send(result);
})

// 模糊查询物品名字
app.get("/searchLose", async (req, res) => {
    const { name, type } = req.query;
    const _name = new RegExp(name, 'i');
    let result = null;
    if (type) {
        result = await Lose.find({
            name: _name,
            type
        });
    } else {
        result = await Lose.find({
            name: _name,
        });
    }

    res.send(result);
})


// 注册
app.post('/register', async (req, res) => {
    const { openid, username, password, date } = req.body;
    const result = await User.findOne({
        username
    });

    if (result) {
        res.send("Registered");
    } else {
        await User.create({
            openid,
            username,
            password,
            date
        });
        res.send("success");
    }
})

// 登录
app.post("/toLogin", async (req, res) => {
    const { username, password } = req.body;
    const result = await User.findOne({
        username
    });
    if (result) {
        if (result.password === password) {
            res.send("success");
        } else {
            res.send("pwdError")
        }
    } else {
        res.send("error");
    }
})

// 小程序端删除寻物或寻主数据
app.post("/deleteLose", async (req, res) => {
    const { _id } = req.body;
    try {
        await Lose.findByIdAndRemove(_id);
        await Collection.deleteMany({
            id: _id
        })
        res.send("success");
    } catch (error) {
        res.send("error");
    }
})

// 小程序端修改寻物或寻主数据
app.post("/updateLose", async (req, res) => {
    const { type, classify1, classify2, name, date, region, phone, desc, imgList, time, openid, id } = req.body;
    try {
        await Lose.findByIdAndUpdate(id, {
            type, classify1, classify2, name, date, region, phone, desc, imgList, time, openid,
        })
        res.send("success");
    } catch (error) {
        res.send("error");
    }
})

// 查询物品详情数据
app.post("/getDetail", async (req, res) => {
    const { _id } = req.body;
    try {
        const result = await Lose.findById(_id);
        res.send(result);
    } catch (error) {
        res.send("error");
    }
})

// 提交评论
app.post("/addComment", async (req, res) => {
    const { avatarUrl, nickName, content, time, _id } = req.body;
    try {
        let result = await Lose.findById(_id);
        let { commentList } = result;
        commentList.push({
            avatarUrl,
            nickName,
            content,
            time,
        })
        await Lose.findByIdAndUpdate(_id, {
            commentList
        })
        result["commentList"] = commentList;
        res.send({
            status: "success",
            data: result
        });
    } catch (error) {
        res.send({
            status: "error",
            data: error
        });
    }
})

// 认领
app.post('/toClaim', async (req, res) => {
    try {
        const { desc, img_url, openid, _id } = req.body;
        await Lose.findByIdAndUpdate(_id, {
            claimInfo: {
                desc,
                img_url,
                openid
            },
            state: 1
        });
        
        res.send("success");
    } catch (error) {
        console.log(error);
        res.send("error");
    }
})

app.listen(3001, () => {
    console.log('server running!');
})